# ESP-TOUR-BD Starter (Prototype v0.1)

এটি একটি responsive web prototype, Android Chrome-এও দেখা যাবে। এটি এখনো production app নয়।

## মোবাইল থেকে চালানোর সহজ উপায়
1. ZIP extract করে `index.html` ফাইলটি খুলে দেখো। Android-এ Chrome দিয়ে খুলতে পারো।
2. অনলাইনে প্রকাশ করতে চাইলে GitHub account খুলে একটি repository তৈরি করে এই ফাইলগুলো upload করো।
3. GitHub Pages বা Netlify-তে deploy করলে website link পাওয়া যাবে।
4. Chrome-এর menu থেকে **Add to Home screen** দিলে ফোনে app-এর মতো shortcut হবে।

## এই সংস্করণে
- Play / My Matches / Results / Profile navigation
- BR, Clash Squad, Lone Wolf ও Free tournament cards
- Tournament filter
- Demo join request (শুধু browser session/পেজে)
- Profile local device-এ save
- Responsive mobile + desktop layout

## এখনো তৈরি হয়নি
- Real login/OTP, database, admin panel
- Live match room ID/password delivery
- Verified results and leaderboard
- Real wallet, deposit, withdrawal or payment gateway

## পরের ধাপ
Supabase/Firebase backend, authentication, database rules, admin dashboard এবং নিরাপদ payment integration যোগ করতে হবে। Real money feature চালুর আগে স্থানীয় আইন, tournament rules, age requirements, payment-provider policies এবং anti-fraud ব্যবস্থা যাচাই করতে হবে।
